public class Buy {

	private String productName;
	private String picProduct;
	private double priceProduct;
	private int piece;
	private String correntDate;

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPicProduct() {
		return picProduct;
	}
	public void setPicProduct(String picProduct) {
		this.picProduct = picProduct;
	}
	public double getPriceProduct() {
		return priceProduct;
	}
	public void setPriceProduct(double priceProduct) {
		this.priceProduct = priceProduct;
	}
	public int getPiece() {
		return piece;
	}
	public void setPiece(int piece) {
		this.piece = piece;
	}
	public String getCorrentDate() {
		return correntDate;
	}
	public void setCorrentDate(String correntDate) {
		this.correntDate = correntDate;
	} 
}
