var numadded = 0;
var subStringHashTag="";
function doAdd() {
    var hashtagStr = document.getElementById("hashtag").value;
    var hashtags = document.getElementById("hashtaglist");

    var check = new RegExp("^[A-Za-z0-9 ]+$");
    if (!check.test(hashtagStr)) {
        alert("Invalid data in hashtag field");
        return;
    }
    subStringHashTag +="#"+hashtagStr;
    if (numadded > 0) {
        hashtags.value = hashtags.value + "\n";
    }
    var hashtagOption = new Option(hashtagStr)

    numadded++;
    hashtags.appendChild(hashtagOption);
    document.getElementById("hashtag").value="";
    document.getElementById("hashtagSend").value=subStringHashTag;
}

function doReset() {
  numadded=0;
  var hashtags = document.getElementById("hashtaglist");
    hashtags.value="";
    hashtags.appendChild("");
}
