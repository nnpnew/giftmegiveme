function login_show() {
	document.getElementById('blank').style.display = "block";
	document.getElementById('header').style.display = "none";
}
function login_hide() {
	document.getElementById('blank').style.display = "none";
	document.getElementById('header').style.display = "block";
}
function userMenu() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}